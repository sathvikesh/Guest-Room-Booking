from django.apps import AppConfig


class RoombookConfig(AppConfig):
    name = 'roombook'
